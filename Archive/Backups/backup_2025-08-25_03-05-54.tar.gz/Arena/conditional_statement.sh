#!/bin/bash

file_name=hero.txt


if [ "Those the file exist in the Arena directory? $file_name" ]
 then
   echo "Hero found"
 else
   echo "Hero missing"
fi 
